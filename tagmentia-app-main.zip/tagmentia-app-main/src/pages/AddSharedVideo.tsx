import { useState, useEffect } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { isSupportedUrl, getUnsupportedPlatformMessage, getPlatform } from "@/utils/urlNormalization";
import { ShareProcessingScreen } from "@/components/share/ShareProcessingScreen";
import { UnsupportedFormatScreen } from "@/components/share/UnsupportedFormatScreen";
import { AddVideoFormScreen } from "@/components/share/AddVideoFormScreen";
import { CategoryPickerModal } from "@/components/share/CategoryPickerModal";
import { SaveConfirmationScreen } from "@/components/share/SaveConfirmationScreen";

interface Category {
  id: string;
  name: string;
  color?: string;
}

export default function AddSharedVideo() {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const { toast } = useToast();

  const [url, setUrl] = useState("");
  const [videoTitle, setVideoTitle] = useState("");
  const [thumbnailUrl, setThumbnailUrl] = useState("");
  const [platform, setPlatform] = useState<"youtube" | "tiktok" | "instagram" | "snapchat" | null>(null);
  const [categoryId, setCategoryId] = useState("");
  const [notes, setNotes] = useState("");
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(false);
  const [processing, setProcessing] = useState(true);
  const [saved, setSaved] = useState(false);
  const [error, setError] = useState("");
  const [unsupported, setUnsupported] = useState(false);
  const [showCategoryPicker, setShowCategoryPicker] = useState(false);

  useEffect(() => {
    const initialize = async () => {
      // Check authentication
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        navigate("/auth/login");
        return;
      }

      // Get shared URL
      const sharedUrl = searchParams.get("url") || searchParams.get("text") || "";
      const decodedUrl = sharedUrl ? decodeURIComponent(sharedUrl) : "";
      setUrl(decodedUrl);

      // Check if URL is supported
      if (decodedUrl && !isSupportedUrl(decodedUrl)) {
        setUnsupported(true);
        setProcessing(false);
        return;
      }

      // Load categories
      const { data: categoriesData } = await supabase
        .from("categories")
        .select("id, name, color")
        .eq("user_id", user.id)
        .order("name");

      if (categoriesData) {
        setCategories(categoriesData);
        if (categoriesData.length === 1) {
          setCategoryId(categoriesData[0].id);
        }
      }

      // Extract platform and set initial data
      if (decodedUrl) {
        const detectedPlatform = getPlatform(decodedUrl);
        if (detectedPlatform) {
          setPlatform(detectedPlatform as "youtube" | "tiktok" | "instagram" | "snapchat");
          setVideoTitle(`${detectedPlatform.charAt(0).toUpperCase() + detectedPlatform.slice(1)} Video`);
        }
      }

      setProcessing(false);
    };

    initialize();
  }, [searchParams, navigate]);

  const handleSave = async () => {
    if (!url || !categoryId) return;

    setLoading(true);
    setError("");

    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("Not authenticated");

      const { data, error: saveError } = await supabase.functions.invoke(
        "save-shared-link",
        {
          body: { url, categoryId, note: notes || undefined },
        }
      );

      if (saveError) throw saveError;

      if (data?.error) {
        if (data.error === "UNSUPPORTED_PLATFORM") {
          toast({
            title: "Unsupported Link",
            description: "This link can't be added to Tagmentia yet. Supported platforms are YouTube, TikTok, Instagram, and Snapchat.",
            variant: "destructive",
          });
        } else if (data.error === "UPGRADE_REQUIRED") {
          navigate("/upgrade");
        } else if (data.error === "DUPLICATE_VIDEO") {
          toast({
            title: "Already Saved",
            description: "This video is already in your collection.",
          });
        } else {
          throw new Error(data.error);
        }
        setLoading(false);
        return;
      }

      setSaved(true);
    } catch (error: any) {
      console.error("Error saving video:", error);
      setError(error.message || "Something went wrong while saving your video. Please try again.");
      toast({
        title: "Couldn't Save Item",
        description: error.message || "Something went wrong while saving your video. Please try again.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleViewItem = () => {
    const category = categories.find((c) => c.id === categoryId);
    if (category) {
      navigate(`/category/${categoryId}`);
    }
  };

  const handleAddAnother = () => {
    setSaved(false);
    setUrl("");
    setVideoTitle("");
    setThumbnailUrl("");
    setPlatform(null);
    setNotes("");
    setError("");
  };

  // Processing screen
  if (processing) {
    return <ShareProcessingScreen />;
  }

  // Unsupported platform screen
  if (unsupported) {
    return (
      <UnsupportedFormatScreen
        url={url}
        onClose={() => navigate(-1)}
      />
    );
  }

  // Success screen
  if (saved) {
    const category = categories.find((c) => c.id === categoryId);
    return (
      <SaveConfirmationScreen
        categoryName={category?.name || "Unknown"}
        onViewItem={handleViewItem}
        onAddAnother={handleAddAnother}
        autoCloseDelay={2000}
      />
    );
  }

  // Main form screen
  if (!platform || categories.length === 0) {
    return <ShareProcessingScreen />;
  }

  return (
    <>
      <AddVideoFormScreen
        url={url}
        title={videoTitle}
        thumbnailUrl={thumbnailUrl}
        platform={platform}
        categories={categories}
        selectedCategoryId={categoryId}
        notes={notes}
        onNotesChange={setNotes}
        onCategoryClick={() => setShowCategoryPicker(true)}
        onSave={handleSave}
        onCancel={() => navigate(-1)}
        isSaving={loading}
        error={error}
      />

      <CategoryPickerModal
        open={showCategoryPicker}
        onClose={() => setShowCategoryPicker(false)}
        categories={categories}
        selectedCategoryId={categoryId}
        onSelectCategory={setCategoryId}
        onCreateNew={() => navigate("/add-category")}
      />
    </>
  );
}
