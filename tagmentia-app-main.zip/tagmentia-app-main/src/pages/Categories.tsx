import { useState, useEffect } from "react";
import { Link, useNavigate, Navigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Plus, Search, SlidersHorizontal, FolderOpen, Grid3X3, List, LayoutGrid } from "lucide-react";

import { Header } from "@/components/Header";
import { CategoryCard } from "@/components/CategoryCard";
import { EditCategoryDialog } from "@/components/EditCategoryDialog";
import { DeleteCategoryDialog } from "@/components/DeleteCategoryDialog";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "@/hooks/use-toast";
import { useDeviceDetection } from "@/hooks/useDeviceDetection";

interface Category {
  id: string;
  name: string;
  color: string;
  description?: string | null;
  count: number;
  updatedAt: string;
  lastUpdated: string;
}

const Categories = () => {
  const { layoutType } = useDeviceDetection();
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState("");
  const [sortBy, setSortBy] = useState("name");
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid");
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(true);
  const [editingCategory, setEditingCategory] = useState<Category | null>(null);
  const [deletingCategory, setDeletingCategory] = useState<Category | null>(null);

  const getTimeAgo = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffInHours = Math.floor((now.getTime() - date.getTime()) / (1000 * 60 * 60));
    if (diffInHours < 1) return 'Just now';
    if (diffInHours < 24) return `${diffInHours}h ago`;
    const diffInDays = Math.floor(diffInHours / 24);
    if (diffInDays < 7) return `${diffInDays}d ago`;
    return date.toLocaleDateString();
  };

  useEffect(() => {
    if (layoutType === 'web') {
      navigate('/categories-web', { replace: true });
      return;
    }

    const fetchCategories = async () => {
      try {
        setLoading(true);
        const { data, error } = await supabase
          .from('categories')
          .select(`
            id,
            name,
            color,
            description,
            updated_at
          `)
          .order('updated_at', { ascending: false });

        if (error) {
          console.error('Error fetching categories:', error);
          return;
        }

        // Get video counts for each category
        const categoriesWithCounts = await Promise.all(
          (data || []).map(async (category) => {
            const { count } = await supabase
              .from('videos')
              .select('*', { count: 'exact', head: true })
              .eq('category_id', category.id);
            
            return {
              ...category,
              videoCount: count || 0
            };
          })
        );

        const mapped = categoriesWithCounts.map((row: any) => ({
          id: row.id as string,
          name: row.name as string,
          color: (row.color as string) || 'blue-ocean',
          description: (row.description as string) || null,
          count: row.videoCount,
          updatedAt: row.updated_at as string,
          lastUpdated: getTimeAgo(row.updated_at as string),
        }));

        setCategories(mapped);
      } catch (error) {
        console.error('Error in fetchCategories:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchCategories();
  }, [layoutType, navigate]);

  const filteredCategories = categories.filter(category =>
    category.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const sortedCategories = [...filteredCategories].sort((a, b) => {
    switch (sortBy) {
      case "name":
        return a.name.localeCompare(b.name);
      case "count":
        return b.count - a.count;
      case "recent":
        return new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime();
      default:
        return 0;
    }
  });


  const handleCategoryClick = (category: any) => {
    navigate(`/category/${category.id}`);
  };

  const refetchCategories = async () => {
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('categories')
        .select(`
          id,
          name,
          color,
          description,
          updated_at
        `)
        .order('updated_at', { ascending: false });

      if (error) {
        console.error('Error fetching categories:', error);
        return;
      }

      // Get video counts for each category
      const categoriesWithCounts = await Promise.all(
        (data || []).map(async (category) => {
          const { count } = await supabase
            .from('videos')
            .select('*', { count: 'exact', head: true })
            .eq('category_id', category.id);
          
          return {
            ...category,
            videoCount: count || 0
          };
        })
      );

      const mapped = categoriesWithCounts.map((row: any) => ({
        id: row.id as string,
        name: row.name as string,
        color: (row.color as string) || 'blue-ocean',
        description: (row.description as string) || null,
        count: row.videoCount,
        updatedAt: row.updated_at as string,
        lastUpdated: getTimeAgo(row.updated_at as string),
      }));

      setCategories(mapped);
    } catch (error) {
      console.error('Error in fetchCategories:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleEdit = (category: Category) => {
    setEditingCategory(category);
  };

  const handleDelete = (category: Category) => {
    setDeletingCategory(category);
  };

  const handleSaveCategory = async (updatedCategory: any) => {
    const { error } = await supabase
      .from('categories')
      .update({
        name: updatedCategory.name,
        description: updatedCategory.description,
        color: updatedCategory.color,
      })
      .eq('id', updatedCategory.id);

    if (error) {
      console.error('Error updating category:', error);
      toast({
        title: "Error",
        description: "Failed to update category. Please try again.",
        variant: "destructive",
      });
      return;
    }

    await refetchCategories();
    setEditingCategory(null);
  };

  const handleDeleteCategory = async (categoryId: string) => {
    // First delete all videos in this category
    const { error: videosError } = await supabase
      .from('videos')
      .delete()
      .eq('category_id', categoryId);

    if (videosError) {
      console.error('Error deleting videos:', videosError);
      toast({
        title: "Error",
        description: "Failed to delete category videos. Please try again.",
        variant: "destructive",
      });
      return;
    }

    // Then delete the category
    const { error: categoryError } = await supabase
      .from('categories')
      .delete()
      .eq('id', categoryId);

    if (categoryError) {
      console.error('Error deleting category:', categoryError);
      toast({
        title: "Error",
        description: "Failed to delete category. Please try again.",
        variant: "destructive",
      });
      return;
    }

    await refetchCategories();
    setDeletingCategory(null);
  };

  return (
    <div className="min-h-screen bg-background">
      <Header title="My Categories" showBack={false}>
        <Link to="/categories/add">
          <Button className="bg-gradient-primary hover:shadow-elevated transition-all duration-300">
            <Plus className="w-4 h-4 mr-2" />
            Add Category
          </Button>
        </Link>
      </Header>
      
      <main className="pb-20 px-4 pt-6">
        {/* Search and Filter */}
        <div className="flex gap-3 mb-6">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
            <Input
              placeholder="Search categories..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 bg-card border-border focus:ring-primary"
            />
          </div>
          <div className="flex gap-2">
            <Button
              variant="outline"
              onClick={() => {
                if (viewMode === "grid") {
                  setViewMode("list");
                } else {
                  // From list view, navigate to categories-grid page
                  navigate("/categories-grid");
                }
              }}
              className="bg-card border-border hover:bg-muted flex items-center gap-2"
            >
              {viewMode === "grid" ? (
                <>
                  <List className="w-4 h-4" />
                  <span className="hidden sm:inline">Basic View</span>
                </>
              ) : (
                <>
                  <LayoutGrid className="w-4 h-4" />
                  <span className="hidden sm:inline">Card Grid</span>
                </>
              )}
            </Button>
            <Select value={sortBy} onValueChange={setSortBy}>
              <SelectTrigger className="w-32 bg-card border-border">
                <SlidersHorizontal className="w-4 h-4 mr-2" />
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="name">Name</SelectItem>
                <SelectItem value="count">Item Count</SelectItem>
                <SelectItem value="recent">Recent</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* Categories Display */}
        {loading ? (
          <div className={viewMode === "grid" ? "grid grid-cols-2 sm:grid-cols-2 lg:grid-cols-3 gap-4" : "space-y-4"}>
            {[1, 2, 3, 4, 5, 6].map((i) => (
              <div key={i} className="bg-card rounded-lg p-4 shadow-card animate-pulse">
                <div className="flex items-start justify-between mb-3">
                  <div className="w-12 h-12 bg-muted rounded-lg"></div>
                  <div className="text-right">
                    <div className="w-8 h-6 bg-muted rounded mb-1"></div>
                    <div className="w-12 h-3 bg-muted rounded"></div>
                  </div>
                </div>
                <div className="space-y-2">
                  <div className="w-3/4 h-4 bg-muted rounded"></div>
                  <div className="w-1/2 h-3 bg-muted rounded"></div>
                </div>
              </div>
            ))}
          </div>
        ) : sortedCategories.length > 0 ? (
          viewMode === "grid" ? (
            <div className="grid grid-cols-2 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {sortedCategories.map((category) => (
                <CategoryCard 
                  key={category.id} 
                  category={category}
                  onCardClick={handleCategoryClick}
                  onEdit={handleEdit}
                  onDelete={handleDelete}
                />
              ))}
            </div>
          ) : (
            <div className="space-y-4">
              {sortedCategories.map((category) => (
                <div 
                  key={category.id}
                  className="bg-card rounded-lg p-4 shadow-card hover:shadow-elevated transition-all duration-300 cursor-pointer group"
                  onClick={() => handleCategoryClick(category)}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-4">
                      <div className={`w-12 h-12 rounded-lg bg-gradient-${category.color} flex items-center justify-center`}>
                        <FolderOpen className="w-6 h-6 text-white" />
                      </div>
                      <div>
                        <h3 className="text-lg font-semibold text-foreground group-hover:text-primary transition-colors">
                          {category.name}
                        </h3>
                        {category.description && (
                          <p className="text-sm text-muted-foreground mt-1">
                            {category.description}
                          </p>
                        )}
                        <p className="text-xs text-muted-foreground mt-1">
                          Updated {category.lastUpdated}
                        </p>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="text-2xl font-bold text-primary mb-1">
                        {category.count}
                      </div>
                      <div className="text-xs text-muted-foreground">
                        {category.count === 1 ? 'item' : 'items'}
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )
        ) : (
          <div className="text-center py-16">
            {searchQuery ? (
              <>
                <Search className="w-16 h-16 mx-auto text-muted-foreground mb-4" />
                <h3 className="text-lg font-medium text-foreground mb-2">
                  No categories found
                </h3>
                <p className="text-muted-foreground mb-4">
                  Try adjusting your search terms
                </p>
              </>
            ) : (
              <>
                <FolderOpen className="w-16 h-16 mx-auto text-muted-foreground mb-4" />
                <h3 className="text-lg font-medium text-foreground mb-2">
                  You have no categories yet
                </h3>
                <p className="text-muted-foreground mb-6">
                  Add your first category to start organizing your videos
                </p>
                <Link to="/categories/add">
                  <Button className="bg-gradient-primary hover:shadow-elevated transition-all duration-300">
                    <Plus className="w-4 h-4 mr-2" />
                    Add Your First Category
                  </Button>
                </Link>
              </>
            )}
          </div>
        )}
      </main>

      
      
      {/* Edit Category Dialog */}
      <EditCategoryDialog
        category={editingCategory}
        isOpen={!!editingCategory}
        onClose={() => setEditingCategory(null)}
        onSave={handleSaveCategory}
      />

      {/* Delete Category Dialog */}
      <DeleteCategoryDialog
        category={deletingCategory}
        isOpen={!!deletingCategory}
        onClose={() => setDeletingCategory(null)}
        onDelete={handleDeleteCategory}
      />
    </div>
  );
};

export default Categories;