import { useState, useEffect } from "react";
import { Link, Navigate } from "react-router-dom";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { 
  Search as SearchIcon, 
  X, 
  Filter, 
  Play, 
  FolderOpen, 
  BookOpen, 
  Clock, 
  Sparkles,
  TrendingUp
} from "lucide-react";
import { Header } from "@/components/Header";

import { VideoItem } from "@/components/VideoItem";
import { CategoryCard } from "@/components/CategoryCard";
import { cn } from "@/lib/utils";
import { useDeviceDetection } from "@/hooks/useDeviceDetection";

const Search = () => {
  const { layoutType } = useDeviceDetection();
  const [searchQuery, setSearchQuery] = useState("");
  const [activeTab, setActiveTab] = useState("all");
  const [sortBy, setSortBy] = useState("relevance");
  const [selectedPlatform, setSelectedPlatform] = useState("all");
  const [isSearching, setIsSearching] = useState(false);

  useEffect(() => {
    if (layoutType === 'web') {
      window.location.href = '/search-web';
    }
  }, [layoutType]);

  // Mock data - replace with actual search results
  const recentSearches = [
    "AI tools",
    "fitness routines", 
    "cooking recipes",
    "javascript tutorial"
  ];

  const trendingSearches = [
    "chatgpt",
    "workout",
    "productivity",
    "design trends"
  ];

  const searchResults = {
    videos: [
      {
        id: 1,
        title: "Complete Guide to ChatGPT for Beginners",
        platform: "YouTube",
        thumbnail: "https://images.unsplash.com/photo-1677442136019-21780ecad995?w=400&h=300&fit=crop",
        duration: "15:42",
        hasReminder: true,
        hasNotes: false,
        addedDate: "2 days ago",
        category: { id: "1", name: "AI Tools", color: "#3B82F6" }
      },
      {
        id: 2,
        title: "AI Tools That Will Change Your Life",
        platform: "TikTok",
        thumbnail: "https://images.unsplash.com/photo-1485827404703-89b55fcc595e?w=400&h=300&fit=crop",
        duration: "0:45",
        hasReminder: false,
        hasNotes: true,
        addedDate: "3 days ago",
        category: { id: "1", name: "AI Tools", color: "#3B82F6" }
      }
    ],
    categories: [
      { id: 1, name: "AI Tools", count: 12, color: "blue", lastUpdated: "2 days ago" },
      { id: 2, name: "Fitness Routines", count: 8, color: "green", lastUpdated: "1 day ago" }
    ],
    notes: [
      {
        id: 1,
        title: "ChatGPT Best Practices",
        content: "Key points about using ChatGPT effectively for content creation...",
        videoTitle: "Complete Guide to ChatGPT",
        createdDate: "2 days ago"
      },
      {
        id: 2,
        title: "Morning Workout Notes",
        content: "Remember to focus on form over speed, especially for squats...",
        videoTitle: "Full Body Morning Routine",
        createdDate: "1 week ago"
      }
    ]
  };

  const platforms = ["All", "YouTube", "TikTok", "Instagram", "Twitter", "Vimeo"];

  useEffect(() => {
    if (searchQuery.trim()) {
      setIsSearching(true);
      // Simulate API call delay
      const timer = setTimeout(() => {
        setIsSearching(false);
      }, 500);
      return () => clearTimeout(timer);
    } else {
      setIsSearching(false);
    }
  }, [searchQuery]);

  const handleSearch = (query: string) => {
    setSearchQuery(query);
  };

  const clearSearch = () => {
    setSearchQuery("");
  };

  const getResultsCount = () => {
    if (!searchQuery.trim()) return 0;
    const videosCount = searchResults.videos.length;
    const categoriesCount = searchResults.categories.length;
    const notesCount = searchResults.notes.length;
    
    switch (activeTab) {
      case "videos": return videosCount;
      case "categories": return categoriesCount;
      case "notes": return notesCount;
      default: return videosCount + categoriesCount + notesCount;
    }
  };

  const hasSearchQuery = searchQuery.trim().length > 0;
  const hasResults = getResultsCount() > 0;

  return (
    <div className="min-h-screen bg-background">
      <Header title="Search" showBack={false} />
      
      <main className="pb-20 px-4 pt-6">
        {/* Search Input */}
        <div className="relative mb-6">
          <SearchIcon className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-5 h-5" />
          <Input
            placeholder="Search videos, categories, and notes..."
            value={searchQuery}
            onChange={(e) => handleSearch(e.target.value)}
            className="pl-12 pr-12 h-12 bg-card border-border focus:ring-primary text-base"
          />
          {searchQuery && (
            <Button
              variant="ghost"
              size="icon"
              onClick={clearSearch}
              className="absolute right-2 top-1/2 transform -translate-y-1/2 hover:bg-muted"
            >
              <X className="w-4 h-4" />
            </Button>
          )}
        </div>

        {/* Filters */}
        {hasSearchQuery && (
          <div className="flex gap-3 mb-6 overflow-x-auto">
            <Select value={selectedPlatform} onValueChange={setSelectedPlatform}>
              <SelectTrigger className="w-32 bg-card border-border">
                <Filter className="w-4 h-4 mr-2" />
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {platforms.map((platform) => (
                  <SelectItem key={platform.toLowerCase()} value={platform.toLowerCase()}>
                    {platform}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            
            <Select value={sortBy} onValueChange={setSortBy}>
              <SelectTrigger className="w-32 bg-card border-border">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="relevance">Relevance</SelectItem>
                <SelectItem value="date">Date Added</SelectItem>
                <SelectItem value="name">Name</SelectItem>
              </SelectContent>
            </Select>
          </div>
        )}

        {/* Search Results */}
        {hasSearchQuery ? (
          <>
            {/* Results Header */}
            <div className="flex items-center justify-between mb-4">
              <p className="text-sm text-muted-foreground">
                {isSearching ? "Searching..." : `${getResultsCount()} results for "${searchQuery}"`}
              </p>
            </div>

            {hasResults ? (
              <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
                <TabsList className="grid w-full grid-cols-4 mb-6">
                  <TabsTrigger value="all">All</TabsTrigger>
                  <TabsTrigger value="videos">Videos</TabsTrigger>
                  <TabsTrigger value="categories">Categories</TabsTrigger>
                  <TabsTrigger value="notes">Notes</TabsTrigger>
                </TabsList>

                <TabsContent value="all" className="space-y-6">
                  {/* Categories Results */}
                  {searchResults.categories.length > 0 && (
                    <div>
                      <h3 className="font-semibold text-foreground mb-3 flex items-center gap-2">
                        <FolderOpen className="w-4 h-4" />
                        Categories ({searchResults.categories.length})
                      </h3>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-6">
                        {searchResults.categories.map((category) => (
                          <Link key={category.id} to={`/category/${category.id}`}>
                            <CategoryCard category={category} />
                          </Link>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Videos Results */}
                  {searchResults.videos.length > 0 && (
                    <div>
                      <h3 className="font-semibold text-foreground mb-3 flex items-center gap-2">
                        <Play className="w-4 h-4" />
                        Videos ({searchResults.videos.length})
                      </h3>
                      <div className="space-y-4 mb-6">
                        {searchResults.videos.map((video) => (
                          <VideoItem key={video.id} video={video} />
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Notes Results */}
                  {searchResults.notes.length > 0 && (
                    <div>
                      <h3 className="font-semibold text-foreground mb-3 flex items-center gap-2">
                        <BookOpen className="w-4 h-4" />
                        Notes ({searchResults.notes.length})
                      </h3>
                      <div className="space-y-3">
                        {searchResults.notes.map((note) => (
                          <Card key={note.id} className="shadow-card hover:shadow-elevated transition-all duration-200 cursor-pointer">
                            <CardContent className="p-4">
                              <div className="flex items-start justify-between gap-3">
                                <div className="flex-1 min-w-0">
                                  <h4 className="font-medium text-foreground mb-1">{note.title}</h4>
                                  <p className="text-sm text-muted-foreground line-clamp-2 mb-2">
                                    {note.content}
                                  </p>
                                  <div className="flex items-center gap-2 text-xs text-muted-foreground">
                                    <Badge variant="outline" className="text-xs">
                                      {note.videoTitle}
                                    </Badge>
                                    <span>•</span>
                                    <span>{note.createdDate}</span>
                                  </div>
                                </div>
                                <BookOpen className="w-5 h-5 text-primary flex-shrink-0" />
                              </div>
                            </CardContent>
                          </Card>
                        ))}
                      </div>
                    </div>
                  )}
                </TabsContent>

                <TabsContent value="videos">
                  <div className="space-y-4">
                    {searchResults.videos.map((video) => (
                      <VideoItem key={video.id} video={video} />
                    ))}
                  </div>
                </TabsContent>

                <TabsContent value="categories">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    {searchResults.categories.map((category) => (
                      <Link key={category.id} to={`/category/${category.id}`}>
                        <CategoryCard category={category} />
                      </Link>
                    ))}
                  </div>
                </TabsContent>

                <TabsContent value="notes">
                  <div className="space-y-3">
                    {searchResults.notes.map((note) => (
                      <Card key={note.id} className="shadow-card hover:shadow-elevated transition-all duration-200 cursor-pointer">
                        <CardContent className="p-4">
                          <div className="flex items-start justify-between gap-3">
                            <div className="flex-1 min-w-0">
                              <h4 className="font-medium text-foreground mb-1">{note.title}</h4>
                              <p className="text-sm text-muted-foreground line-clamp-2 mb-2">
                                {note.content}
                              </p>
                              <div className="flex items-center gap-2 text-xs text-muted-foreground">
                                <Badge variant="outline" className="text-xs">
                                  {note.videoTitle}
                                </Badge>
                                <span>•</span>
                                <span>{note.createdDate}</span>
                              </div>
                            </div>
                            <BookOpen className="w-5 h-5 text-primary flex-shrink-0" />
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </TabsContent>
              </Tabs>
            ) : (
              /* No Results */
              <div className="text-center py-16">
                <SearchIcon className="w-16 h-16 mx-auto text-muted-foreground mb-4" />
                <h3 className="text-lg font-medium text-foreground mb-2">
                  No results found
                </h3>
                <p className="text-muted-foreground mb-4">
                  Try adjusting your search terms or filters
                </p>
                <Button
                  variant="outline"
                  onClick={clearSearch}
                  className="border-border hover:bg-muted"
                >
                  Clear Search
                </Button>
              </div>
            )}
          </>
        ) : (
          /* Search Suggestions */
          <div className="space-y-6">
            {/* Recent Searches */}
            <div>
              <h3 className="font-semibold text-foreground mb-3 flex items-center gap-2">
                <Clock className="w-4 h-4" />
                Recent Searches
              </h3>
              <div className="flex flex-wrap gap-2">
                {recentSearches.map((search, index) => (
                  <Button
                    key={index}
                    variant="outline"
                    size="sm"
                    onClick={() => handleSearch(search)}
                    className="border-border hover:bg-muted"
                  >
                    {search}
                  </Button>
                ))}
              </div>
            </div>

            {/* Trending Searches */}
            <div>
              <h3 className="font-semibold text-foreground mb-3 flex items-center gap-2">
                <TrendingUp className="w-4 h-4" />
                Trending
              </h3>
              <div className="flex flex-wrap gap-2">
                {trendingSearches.map((search, index) => (
                  <Button
                    key={index}
                    variant="outline"
                    size="sm"
                    onClick={() => handleSearch(search)}
                    className="border-border hover:bg-muted"
                  >
                    <Sparkles className="w-3 h-3 mr-1" />
                    {search}
                  </Button>
                ))}
              </div>
            </div>

            {/* Search Tips */}
            <Card className="shadow-card">
              <CardContent className="p-4">
                <h3 className="font-semibold text-foreground mb-3">Search Tips</h3>
                <ul className="space-y-2 text-sm text-muted-foreground">
                  <li>• Search by video title, category name, or note content</li>
                  <li>• Use filters to narrow down results by platform or date</li>
                  <li>• Try searching for specific topics or keywords</li>
                  <li>• Use quotes for exact phrase matching</li>
                </ul>
              </CardContent>
            </Card>
          </div>
        )}
      </main>

      
    </div>
  );
};

export default Search;