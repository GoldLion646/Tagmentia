import { useState, useEffect } from "react";
import { useNavigate, Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { Plus, MoreVertical, BookOpen, Monitor, Music, Dumbbell, Edit, Trash2, List, Search, SlidersHorizontal, Grid3X3 } from "lucide-react";

import { Header } from "@/components/Header";
import { EditCategoryDialog } from "@/components/EditCategoryDialog";
import { DeleteCategoryDialog } from "@/components/DeleteCategoryDialog";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "@/hooks/use-toast";

interface Category {
  id: string;
  name: string;
  color: string;
  description?: string | null;
  count: number;
  updatedAt: string;
  lastUpdated: string;
  recentActivity?: string;
}

const CategoriesGrid = () => {
  const navigate = useNavigate();
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(true);
  const [editingCategory, setEditingCategory] = useState<Category | null>(null);
  const [deletingCategory, setDeletingCategory] = useState<Category | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [sortBy, setSortBy] = useState("name");

  // Icon mapping for different category types
  const getCategoryIcon = (categoryName: string, description?: string) => {
    const name = categoryName.toLowerCase();
    const desc = description?.toLowerCase() || '';
    
    if (name.includes('education') || desc.includes('learning') || desc.includes('tutorial')) {
      return BookOpen;
    }
    if (name.includes('technology') || desc.includes('tech') || desc.includes('gadget')) {
      return Monitor;
    }
    if (name.includes('entertainment') || desc.includes('music') || desc.includes('movie')) {
      return Music;
    }
    if (name.includes('lifestyle') || desc.includes('health') || desc.includes('fitness')) {
      return Dumbbell;
    }
    return BookOpen; // Default icon
  };

  // Map semantic color names to gradients
  const getGradientStyle = (colorName: string) => {
    const gradientMap: { [key: string]: string } = {
      'purple-cosmic': 'linear-gradient(135deg, #8B5CF6 0%, #3B82F6 100%)',
      'blue-ocean': 'linear-gradient(135deg, #3B82F6 0%, #1D4ED8 100%)',
      'lime-forest': 'linear-gradient(135deg, #84CC16 0%, #16A34A 100%)',
      'green-emerald': 'linear-gradient(135deg, #10B981 0%, #059669 100%)',
      'teal-navy': 'linear-gradient(135deg, #14B8A6 0%, #0F766E 100%)',
      'cyan-azure': 'linear-gradient(135deg, #06B6D4 0%, #0891B2 100%)',
      'lime-vibrant': 'linear-gradient(135deg, #A3E635 0%, #65A30D 100%)',
      'red-fire': 'linear-gradient(135deg, #EF4444 0%, #DC2626 100%)',
      'orange-sunset': 'linear-gradient(135deg, #F97316 0%, #EA580C 100%)',
    };
    return gradientMap[colorName] || 'linear-gradient(135deg, #8B5CF6 0%, #3B82F6 100%)';
  };

  const getTimeAgo = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffInHours = Math.floor((now.getTime() - date.getTime()) / (1000 * 60 * 60));
    if (diffInHours < 1) return 'Just now';
    if (diffInHours < 24) return `${diffInHours}h ago`;
    const diffInDays = Math.floor(diffInHours / 24);
    if (diffInDays < 7) return `${diffInDays}d ago`;
    return date.toLocaleDateString();
  };

  const getRecentActivity = async (categoryId: string) => {
    const { data } = await supabase
      .from('videos')
      .select('title, created_at')
      .eq('category_id', categoryId)
      .order('created_at', { ascending: false })
      .limit(1);
    
    if (data && data.length > 0) {
      return `Recent: ${data[0].title}`;
    }
    return 'No recent activity';
  };

  useEffect(() => {
    const fetchCategories = async () => {
      try {
        setLoading(true);
        const { data, error } = await supabase
          .from('categories')
          .select(`
            id,
            name,
            color,
            description,
            updated_at
          `)
          .order('updated_at', { ascending: false });

        if (error) {
          console.error('Error fetching categories:', error);
          return;
        }

        // Get video counts and recent activity for each category
        const categoriesWithData = await Promise.all(
          (data || []).map(async (category) => {
            const { count } = await supabase
              .from('videos')
              .select('*', { count: 'exact', head: true })
              .eq('category_id', category.id);
            
            const recentActivity = await getRecentActivity(category.id);
            
            return {
              ...category,
              videoCount: count || 0,
              recentActivity
            };
          })
        );

        const mapped = categoriesWithData.map((row: any) => ({
          id: row.id as string,
          name: row.name as string,
          color: (row.color as string) || 'blue-ocean',
          description: (row.description as string) || null,
          count: row.videoCount,
          updatedAt: row.updated_at as string,
          lastUpdated: getTimeAgo(row.updated_at as string),
          recentActivity: row.recentActivity,
        }));

        setCategories(mapped);
      } catch (error) {
        console.error('Error in fetchCategories:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchCategories();
  }, []);

  const filteredCategories = categories.filter(category =>
    category.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const sortedCategories = [...filteredCategories].sort((a, b) => {
    switch (sortBy) {
      case "name":
        return a.name.localeCompare(b.name);
      case "count":
        return b.count - a.count;
      case "recent":
        return new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime();
      default:
        return 0;
    }
  });

  const handleCategoryClick = (category: Category) => {
    navigate(`/category/${category.id}`);
  };

  const handleEdit = (e: React.MouseEvent, category: Category) => {
    e.stopPropagation();
    setEditingCategory(category);
  };

  const handleDelete = (e: React.MouseEvent, category: Category) => {
    e.stopPropagation();
    setDeletingCategory(category);
  };

  const refetchCategories = async () => {
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('categories')
        .select(`
          id,
          name,
          color,
          description,
          updated_at
        `)
        .order('updated_at', { ascending: false });

      if (error) {
        console.error('Error fetching categories:', error);
        return;
      }

      const categoriesWithData = await Promise.all(
        (data || []).map(async (category) => {
          const { count } = await supabase
            .from('videos')
            .select('*', { count: 'exact', head: true })
            .eq('category_id', category.id);
          
          const recentActivity = await getRecentActivity(category.id);
          
          return {
            ...category,
            videoCount: count || 0,
            recentActivity
          };
        })
      );

      const mapped = categoriesWithData.map((row: any) => ({
        id: row.id as string,
        name: row.name as string,
        color: (row.color as string) || 'blue-ocean',
        description: (row.description as string) || null,
        count: row.videoCount,
        updatedAt: row.updated_at as string,
        lastUpdated: getTimeAgo(row.updated_at as string),
        recentActivity: row.recentActivity,
      }));

      setCategories(mapped);
    } catch (error) {
      console.error('Error in fetchCategories:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSaveCategory = async (updatedCategory: any) => {
    const { error } = await supabase
      .from('categories')
      .update({
        name: updatedCategory.name,
        description: updatedCategory.description,
        color: updatedCategory.color,
      })
      .eq('id', updatedCategory.id);

    if (error) {
      console.error('Error updating category:', error);
      toast({
        title: "Error",
        description: "Failed to update category. Please try again.",
        variant: "destructive",
      });
      return;
    }

    await refetchCategories();
    setEditingCategory(null);
    toast({
      title: "Category Updated",
      description: "Your category has been successfully updated.",
    });
  };

  const handleDeleteCategory = async (categoryId: string) => {
    // First delete all videos in this category
    const { error: videosError } = await supabase
      .from('videos')
      .delete()
      .eq('category_id', categoryId);

    if (videosError) {
      console.error('Error deleting videos:', videosError);
      toast({
        title: "Error",
        description: "Failed to delete category videos. Please try again.",
        variant: "destructive",
      });
      return;
    }

    // Then delete the category
    const { error: categoryError } = await supabase
      .from('categories')
      .delete()
      .eq('id', categoryId);

    if (categoryError) {
      console.error('Error deleting category:', categoryError);
      toast({
        title: "Error",
        description: "Failed to delete category. Please try again.",
        variant: "destructive",
      });
      return;
    }

    await refetchCategories();
    setDeletingCategory(null);
    toast({
      title: "Category Deleted",
      description: "Category and all its videos have been removed.",
    });
  };

  return (
    <div className="min-h-screen bg-background">
      <Header title="My Categories" showBack={false}>
        <Button
          onClick={() => navigate('/categories/add')}
          className="bg-gradient-primary hover:shadow-elevated transition-all duration-300"
        >
          <Plus className="w-4 h-4 mr-2" />
          Add Category
        </Button>
      </Header>
      
      <main className="pb-20 px-4 pt-6">
        {/* Search and Filter */}
        <div className="flex gap-3 mb-6">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
            <Input
              placeholder="Search categories..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 bg-card border-border focus:ring-primary"
            />
          </div>
          <div className="flex gap-2">
            <Button
              variant="outline"
              onClick={() => navigate("/categories")}
              className="bg-card border-border hover:bg-muted flex items-center gap-2"
            >
              <List className="w-4 h-4" />
              <span className="hidden sm:inline">Basic View</span>
            </Button>
            <Select value={sortBy} onValueChange={setSortBy}>
              <SelectTrigger className="w-32 bg-card border-border">
                <SlidersHorizontal className="w-4 h-4 mr-2" />
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="name">Name</SelectItem>
                <SelectItem value="count">Video Count</SelectItem>
                <SelectItem value="recent">Recent</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
        {/* Categories Grid */}
        {loading ? (
          <div className="grid grid-cols-2 gap-4">
            {[1, 2, 3, 4].map((i) => (
              <div key={i} className="bg-card rounded-xl p-6 shadow-card animate-pulse h-48">
                <div className="flex items-center justify-between mb-4">
                  <div className="w-8 h-8 bg-muted rounded-lg"></div>
                  <div className="w-6 h-6 bg-muted rounded"></div>
                </div>
                <div className="space-y-3">
                  <div className="w-3/4 h-5 bg-muted rounded"></div>
                  <div className="w-1/2 h-3 bg-muted rounded"></div>
                  <div className="w-16 h-4 bg-muted rounded"></div>
                  <div className="w-full h-3 bg-muted rounded"></div>
                </div>
              </div>
            ))}
          </div>
        ) : sortedCategories.length > 0 ? (
          <div className="grid grid-cols-2 gap-4">
            {sortedCategories.map((category) => {
              const IconComponent = getCategoryIcon(category.name, category.description || '');
              return (
                <div
                  key={category.id}
                  className="relative bg-white rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300 cursor-pointer group overflow-hidden"
                  onClick={() => handleCategoryClick(category)}
                >
                  {/* Gradient Top Section */}
                  <div 
                    className="relative p-4 pb-6 bg-gradient-primary"
                    style={{
                      borderRadius: '16px 16px 0 0'
                    }}
                  >
                    {/* Header */}
                    <div className="flex items-start justify-between mb-4">
                      <div className="w-8 h-8 bg-white/30 rounded-lg flex items-center justify-center backdrop-blur-sm">
                        <IconComponent className="w-4 h-4 text-white" />
                      </div>
                      
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button 
                            variant="ghost" 
                            size="icon" 
                            className="text-white hover:bg-white/20 h-8 w-8 rounded-full"
                            onClick={(e) => e.stopPropagation()}
                          >
                            <MoreVertical className="w-4 h-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end" className="w-48">
                          <DropdownMenuItem onClick={(e) => handleEdit(e, category)}>
                            <Edit className="w-4 h-4 mr-2" />
                            Edit Category
                          </DropdownMenuItem>
                          <DropdownMenuItem 
                            onClick={(e) => handleDelete(e, category)}
                            className="text-destructive focus:text-destructive"
                          >
                            <Trash2 className="w-4 h-4 mr-2" />
                            Delete Category
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>

                    {/* Category Title and Description */}
                    <div>
                      <h3 className="text-white font-bold text-lg mb-1 line-clamp-1">
                        {category.name}
                      </h3>
                      {category.description && (
                        <p className="text-white/80 text-xs line-clamp-1">
                          {category.description}
                        </p>
                      )}
                    </div>
                  </div>

                  {/* White Bottom Section */}
                  <div className="bg-white p-4 pt-3">
                    {/* Video Count */}
                    <div className="flex items-center gap-2 mb-2">
                      <div className="w-3 h-3 flex items-center justify-center">
                        <div className="w-0 h-0 border-l-[5px] border-l-gray-700 border-t-[3px] border-t-transparent border-b-[3px] border-b-transparent"></div>
                      </div>
                      <span className="text-gray-900 font-semibold text-sm">
                        {category.count} videos
                      </span>
                    </div>
                    
                    {/* Recent Activity */}
                    <p className="text-gray-600 text-xs line-clamp-2 leading-relaxed">
                      {category.recentActivity}
                    </p>
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          <div className="text-center py-16">
            {searchQuery ? (
              <>
                <Search className="w-16 h-16 mx-auto text-muted-foreground mb-4" />
                <h3 className="text-lg font-medium text-foreground mb-2">
                  No categories found
                </h3>
                <p className="text-muted-foreground mb-4">
                  Try adjusting your search terms
                </p>
              </>
            ) : (
              <>
                <BookOpen className="w-16 h-16 mx-auto text-muted-foreground mb-4" />
                <h3 className="text-lg font-medium text-foreground mb-2">
                  You have no categories yet
                </h3>
                <p className="text-muted-foreground mb-6">
                  Add your first category to start organizing your videos
                </p>
                <Button
                  onClick={() => navigate('/categories/add')}
                  className="bg-gradient-primary hover:shadow-elevated transition-all duration-300"
                >
                  <Plus className="w-4 h-4 mr-2" />
                  Add Your First Category
                </Button>
              </>
            )}
          </div>
        )}
      </main>

      
      
      {/* Edit Category Dialog */}
      <EditCategoryDialog
        category={editingCategory}
        isOpen={!!editingCategory}
        onClose={() => setEditingCategory(null)}
        onSave={handleSaveCategory}
      />

      {/* Delete Category Dialog */}
      <DeleteCategoryDialog
        category={deletingCategory}
        isOpen={!!deletingCategory}
        onClose={() => setDeletingCategory(null)}
        onDelete={handleDeleteCategory}
      />
    </div>
  );
};

export default CategoriesGrid;