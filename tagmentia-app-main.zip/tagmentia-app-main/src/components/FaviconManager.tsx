import { useEffect } from 'react';
import { useLogoConfiguration } from '@/hooks/useLogoConfiguration';

// Function to update manifest icons dynamically
function updateManifestIcons(logoUrl: string, faviconUrl: string) {
  try {
    // Remove old manifest link
    const oldManifest = document.querySelector('link[rel="manifest"]');
    if (oldManifest) {
      oldManifest.remove();
    }

    // Create new manifest with dynamic icons
    const manifest = {
      name: "Tagmentia",
      short_name: "Tagmentia",
      description: "Organize and manage your video collections",
      start_url: "/",
      display: "standalone",
      background_color: "#ffffff",
      theme_color: "#3B82F6",
      orientation: "portrait-primary",
      icons: [
        {
          src: faviconUrl,
          sizes: "64x64 32x32 24x24 16x16",
          type: "image/x-icon"
        },
        {
          src: logoUrl,
          sizes: "192x192",
          type: "image/png",
          purpose: "any maskable"
        },
        {
          src: logoUrl,
          sizes: "512x512",
          type: "image/png",
          purpose: "any maskable"
        }
      ],
      share_target: {
        action: "/add",
        method: "GET",
        enctype: "application/x-www-form-urlencoded",
        params: {
          title: "title",
          text: "text",
          url: "url"
        }
      }
    };

    // Create blob URL for dynamic manifest
    const manifestBlob = new Blob([JSON.stringify(manifest)], { type: 'application/json' });
    const manifestUrl = URL.createObjectURL(manifestBlob);

    // Add new manifest link
    const link = document.createElement('link');
    link.rel = 'manifest';
    link.href = manifestUrl;
    document.head.appendChild(link);
  } catch (error) {
    console.error('Failed to update manifest icons:', error);
  }
}

export function FaviconManager() {
  const { currentFaviconUrl, currentLogoUrl } = useLogoConfiguration();

  useEffect(() => {
    const faviconHref = currentFaviconUrl || '/favicon.ico';
    const logoHref = currentFaviconUrl || currentLogoUrl || '/favicon.ico';

    const ensureLink = (rel: string, href: string, id?: string) => {
      let link = document.querySelector<HTMLLinkElement>(id ? `#${id}` : `link[rel="${rel}"]`);
      if (!link) {
        link = document.createElement('link');
        link.rel = rel;
        if (id) link.id = id;
        document.head.appendChild(link);
      }
      const absolute = new URL(href, window.location.origin).href;
      if (link.href !== absolute) {
        link.href = absolute;
      }
    };

    // Update all favicon and icon links
    ensureLink('icon', faviconHref, 'favicon');
    ensureLink('shortcut icon', faviconHref);
    ensureLink('apple-touch-icon', logoHref, 'apple-touch-icon');
    
    // Update manifest icons dynamically for PWA
    updateManifestIcons(logoHref, faviconHref);
  }, [currentFaviconUrl, currentLogoUrl]);

  return null;
}
