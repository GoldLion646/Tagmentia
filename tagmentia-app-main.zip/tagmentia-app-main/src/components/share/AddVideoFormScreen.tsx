import { useState } from "react";
import { Youtube, Music, Instagram, Ghost, ExternalLink, Folder } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { cn } from "@/lib/utils";

interface Category {
  id: string;
  name: string;
  color?: string;
}

interface AddVideoFormScreenProps {
  url: string;
  title: string;
  thumbnailUrl?: string;
  platform: "youtube" | "tiktok" | "instagram" | "snapchat";
  categories: Category[];
  selectedCategoryId?: string;
  notes: string;
  onNotesChange: (notes: string) => void;
  onCategoryClick: () => void;
  onSave: () => void;
  onCancel: () => void;
  isSaving?: boolean;
  error?: string;
  thumbnailError?: boolean;
  onRetryThumbnail?: () => void;
}

const platformIcons = {
  youtube: { Icon: Youtube, color: "text-red-500", bgColor: "bg-red-500/10" },
  tiktok: { Icon: Music, color: "text-foreground", bgColor: "bg-muted" },
  instagram: { Icon: Instagram, color: "text-pink-500", bgColor: "bg-pink-500/10" },
  snapchat: { Icon: Ghost, color: "text-yellow-500", bgColor: "bg-yellow-500/10" },
};

export const AddVideoFormScreen = ({
  url,
  title,
  thumbnailUrl,
  platform,
  categories,
  selectedCategoryId,
  notes,
  onNotesChange,
  onCategoryClick,
  onSave,
  onCancel,
  isSaving = false,
  error,
  thumbnailError,
  onRetryThumbnail,
}: AddVideoFormScreenProps) => {
  const selectedCategory = categories.find((c) => c.id === selectedCategoryId);
  const { Icon, color, bgColor } = platformIcons[platform] || platformIcons.youtube;

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-2xl mx-auto p-6 space-y-6 animate-fade-in">
        {/* Header */}
        <div className="flex items-center justify-between">
          <h1 className="text-2xl font-semibold text-foreground">Add Video</h1>
          <Button variant="ghost" onClick={onCancel} disabled={isSaving}>
            Cancel
          </Button>
        </div>

        {/* Error Alert */}
        {error && (
          <Alert variant="destructive">
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        {/* Thumbnail */}
        <div className="bg-card rounded-2xl border border-border/50 overflow-hidden shadow-sm">
          {thumbnailUrl && !thumbnailError ? (
            <div className="aspect-video relative group">
              <img
                src={thumbnailUrl}
                alt={title}
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
            </div>
          ) : (
            <div className="aspect-video bg-muted/50 flex items-center justify-center">
              <div className="text-center space-y-2">
                <div className={cn("w-16 h-16 mx-auto rounded-full flex items-center justify-center", bgColor)}>
                  <Icon className={cn("w-8 h-8", color)} />
                </div>
                {thumbnailError && onRetryThumbnail && (
                  <Button variant="outline" size="sm" onClick={onRetryThumbnail}>
                    Retry Thumbnail
                  </Button>
                )}
              </div>
            </div>
          )}
        </div>

        {/* Video Info */}
        <div className="space-y-4">
          {/* Title */}
          <div className="space-y-2">
            <Label htmlFor="title">Video Title</Label>
            <Input
              id="title"
              value={title}
              readOnly
              className="bg-muted/50 border-border/50"
            />
          </div>

          {/* Platform Tag */}
          <div className="flex items-center gap-2">
            <div className={cn("px-4 py-2 rounded-lg flex items-center gap-2", bgColor)}>
              <Icon className={cn("w-4 h-4", color)} />
              <span className={cn("text-sm font-medium capitalize", color)}>
                {platform}
              </span>
            </div>
          </div>

          {/* URL */}
          <div className="space-y-2">
            <Label htmlFor="url">URL</Label>
            <div className="relative">
              <Input
                id="url"
                value={url}
                readOnly
                className="bg-muted/50 border-border/50 pr-10"
              />
              <button
                onClick={() => window.open(url, "_blank")}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
              >
                <ExternalLink className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Category */}
          <div className="space-y-2">
            <Label>Category</Label>
            <button
              onClick={onCategoryClick}
              className="w-full flex items-center gap-3 p-4 rounded-xl border-2 border-border/50 bg-card hover:bg-accent/50 transition-colors"
            >
              {selectedCategory ? (
                <>
                  <div
                    className="w-12 h-12 rounded-lg flex items-center justify-center"
                    style={{
                      backgroundColor: selectedCategory.color
                        ? `${selectedCategory.color}20`
                        : "hsl(var(--muted))",
                    }}
                  >
                    <Folder
                      className="w-6 h-6"
                      style={{
                        color: selectedCategory.color || "hsl(var(--muted-foreground))",
                      }}
                    />
                  </div>
                  <span className="flex-1 text-left font-medium text-foreground">
                    {selectedCategory.name}
                  </span>
                </>
              ) : (
                <>
                  <div className="w-12 h-12 rounded-lg bg-muted flex items-center justify-center">
                    <Folder className="w-6 h-6 text-muted-foreground" />
                  </div>
          <span className="flex-1 text-left text-muted-foreground">
            Choose a category
          </span>
                </>
              )}
            </button>
          </div>

          {/* Notes */}
          <div className="space-y-2">
            <Label htmlFor="notes">Notes (Optional)</Label>
            <Textarea
              id="notes"
              value={notes}
              onChange={(e) => onNotesChange(e.target.value)}
              placeholder="Add notes or context..."
              className="min-h-[100px] resize-none"
            />
          </div>
        </div>

        {/* Actions */}
        <div className="flex gap-3 pt-4">
          <Button
            variant="outline"
            onClick={onCancel}
            disabled={isSaving}
            className="flex-1 h-12 text-base"
          >
            Cancel
          </Button>
          <Button
            onClick={onSave}
            disabled={!selectedCategoryId || isSaving}
            className="flex-1 h-12 text-base font-medium"
          >
            {isSaving ? "Saving..." : "Save to Tagmentia"}
          </Button>
        </div>
      </div>
    </div>
  );
};
