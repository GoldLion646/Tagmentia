import { useEffect, useState } from "react";
import { Loader2 } from "lucide-react";

interface ShareProcessingScreenProps {
  onTimeout?: () => void;
}

export const ShareProcessingScreen = ({ onTimeout }: ShareProcessingScreenProps) => {
  const [showFallback, setShowFallback] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => {
      setShowFallback(true);
      onTimeout?.();
    }, 3000);

    return () => clearTimeout(timer);
  }, [onTimeout]);

  return (
    <div className="min-h-screen flex items-center justify-center bg-background p-6">
      <div className="text-center space-y-6 animate-fade-in">
        <div className="flex justify-center mb-8 relative">
          {/* Pulsing glow background */}
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="w-24 h-24 rounded-full bg-primary/20 animate-pulse-glow" />
          </div>
          
          {/* Loader with icon */}
          <div className="relative w-20 h-20 rounded-2xl bg-primary/10 flex items-center justify-center">
            <Loader2 className="w-10 h-10 text-primary animate-spin" />
          </div>
        </div>

        <div className="space-y-2">
          <h2 className="text-2xl font-semibold text-foreground">
            Processing your link...
          </h2>
          <p className="text-muted-foreground text-sm">
            Hang tight, we're fetching the details.
          </p>
        </div>

        {showFallback && (
          <p className="text-sm text-muted-foreground animate-fade-in">
            This is taking longer than usual... still processing.
          </p>
        )}
      </div>
    </div>
  );
};
