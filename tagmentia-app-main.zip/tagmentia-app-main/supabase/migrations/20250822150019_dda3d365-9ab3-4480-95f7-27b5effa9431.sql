-- Add birth_date column to profiles table
ALTER TABLE public.profiles 
ADD COLUMN birth_date date;